# Headless AOD for Samsung Galaxy (One UI 6–9 / Android 14–17)

An ultra-lightweight, zero-permission, headless Always On Display engine in Kotlin with minimal battery percentage and customizable space placement.

## Key Features
- **Headless Architecture:** Zero launcher icon (`LAUNCHER` intent filter omitted). App only shows up in *Settings > Apps*.
- **Zero Permissions:** 100% offline, private, zero battery-draining background sync. No `INTERNET` permission in manifest.
- **Minimal Battery Percentage:** Updated passively via `Intent.ACTION_BATTERY_CHANGED` (lightweight sticky system callback, 0% CPU wake).
- **Customizable Display Position:** Drag the clock anywhere on the display to place it in any custom position. Coordinates are persisted across boots.
- **Samsung One UI Lock Screen Styles:**
  - Style 0: One UI Standard Horizontal (`10:45`)
  - Style 1: One UI Signature Stacked (`10` over `45`)
  - Long-press clock on AOD to cycle styles or configure via Accessibility settings.
- **Immortal Background Service:** Uses `AccessibilityService` bound directly to Android's `system_server`. Never killed by One UI's background process killer, and automatically starts on device boot. Deliberately exempted by Android OS from Background Activity Launch (BAL) restrictions.
- **Screen-Off Trigger:** Dynamically registers `ACTION_SCREEN_OFF` and launches `AODActivity` with `FLAG_ACTIVITY_NEW_TASK`.
- **True Black AMOLED UI:** `#000000` window background, zero power on OLED sub-pixels.
- **Hardware Brightness:** Clamped to `0.05f` (5%) to save battery.
- **Burn-in Protection:** Sub-pixel jitter of -15px to +15px on X and Y every 5 minutes around your custom chosen position.
- **Double-Tap Wake:** Double-tap anywhere to immediately dismiss the AOD and show the Samsung lock screen.